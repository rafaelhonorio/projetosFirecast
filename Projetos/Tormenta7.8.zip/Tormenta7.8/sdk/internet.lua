internet = require("delayedLoad.dlua").new("internetCore.dlua");
return internet;
