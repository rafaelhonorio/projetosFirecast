fireDrive = require("delayedLoad.dlua").new("fireDriveCore.dlua");
return fireDrive;
